package br.unipar.frameworksweb.slitherunipar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SlitherUniparApplicationTests {

    @Test
    void contextLoads() {
    }

}
